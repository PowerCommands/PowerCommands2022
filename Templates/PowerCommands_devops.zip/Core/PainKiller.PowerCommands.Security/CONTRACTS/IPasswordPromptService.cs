﻿namespace $safeprojectname$.Contracts;

public interface IPasswordPromptService
{
    string ReadPassword();
}