﻿namespace $safeprojectname$.Utils.DisplayTable;

public interface IColumnRender
{
    void Write(string value);
}