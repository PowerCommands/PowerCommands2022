﻿namespace $safeprojectname$.Enums;

public enum ParameterType
{
    Argument,
    Quote,
    Option,
    Secret
}