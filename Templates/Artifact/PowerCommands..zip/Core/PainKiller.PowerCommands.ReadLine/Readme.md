﻿# ABOUT READLINE
A Pure C# GNU-Readline like library for .NET/.NET Core

Published on Github by Toni Solarin-Sodara
https://github.com/tonerdo

The core funtionallity is the same, but some code is added to suit the need for PowerCommands, the license modell is still the same.

## MIT License permissions
- Commercial use
- Modification
- Distribution
- Private use

