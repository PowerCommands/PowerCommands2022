﻿namespace $safeprojectname$.Contracts;
public interface IPowerCommandsManager
{
    void Run(string[] args);
}