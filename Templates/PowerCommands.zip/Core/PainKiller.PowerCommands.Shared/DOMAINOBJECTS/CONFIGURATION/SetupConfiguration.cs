﻿namespace $safeprojectname$.DomainObjects.Configuration
{
    public class SetupConfiguration
    {
        public string User { get; set; } = "";
        public DateTime Setup { get; set; }
    }
}