﻿namespace $safeprojectname$.DomainObjects.Configuration
{
    public class BookmarkConfiguration
    {
        public List<BookmarkItemConfiguration> Bookmarks { get; set; } = new();
    }
}