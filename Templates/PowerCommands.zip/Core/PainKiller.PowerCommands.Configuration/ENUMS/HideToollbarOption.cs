﻿namespace $safeprojectname$.Enums;

public enum HideToollbarOption
{
    Never,
    OnTextChange,
    OnCommandHighlighted
}