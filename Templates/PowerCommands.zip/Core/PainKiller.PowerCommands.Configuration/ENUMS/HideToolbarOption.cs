﻿namespace $safeprojectname$.Enums
{
    public enum HideToolbarOption
    {
        Never,
        OnTextChange,
        OnCommandHighlighted
    }
}