﻿namespace $safeprojectname$.Contracts
{
    public interface IConsoleCommandTable { }
}