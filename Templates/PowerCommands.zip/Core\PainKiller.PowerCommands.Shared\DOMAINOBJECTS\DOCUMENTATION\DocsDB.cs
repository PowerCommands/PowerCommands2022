﻿namespace $safeprojectname$.DomainObjects.Documentation
{
    public class DocsDB
    {
        public List<Doc> Docs { get; set; } = new();
    }
}