﻿namespace $safeprojectname$.DomainObjects.Configuration
{
    public class EnvironmentItemConfiguration
    {
        public string Name { get; set; } = "Name";
        public string EnvironmentVariableTarget { get; set; } = "User";
    }
}