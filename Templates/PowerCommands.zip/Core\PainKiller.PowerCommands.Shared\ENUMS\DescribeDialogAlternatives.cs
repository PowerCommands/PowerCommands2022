﻿namespace $safeprojectname$.Enums;

public enum DescribeDialogAlternatives
{
    Continue = 0,
    Open = 1,
    Edit = 2,
    Delete = 4,
    CreateMarkdownFile = 8,
    UseYourAIService = 16
}