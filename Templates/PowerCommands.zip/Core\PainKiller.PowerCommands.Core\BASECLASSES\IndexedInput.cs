﻿namespace $safeprojectname$.BaseClasses;

public class IndexedInput
{
    public short Index { get; set; }
    public string Value { get; set; } = "";
}