﻿namespace $safeprojectname$.Utils.DisplayTable
{
    public enum Alignment
    {
        Left,
        Right
    }
}