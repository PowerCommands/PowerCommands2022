﻿namespace $safeprojectname$.Utils.DisplayTable;

public enum ColumnRenderFormat
{
    None,
    Standard,
    SucessOrFailure
}