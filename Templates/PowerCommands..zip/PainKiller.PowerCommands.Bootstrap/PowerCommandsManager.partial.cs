namespace $safeprojectname$;
public partial class PowerCommandsManager
{
    private void RunCustomCode()
    {
        //Add your custom code here, som example code below shows an example on how could find a command an run a method, could be a special method to add code completion to that command or something like that, note that the InitializeCustomCompletion() does not exist.
        //var myCommand = (DemoCommand)IPowerCommandsRuntime.DefaultInstance.Commands.First(c => c.Identifier == "DemoCommand");
        //myCommand.InitializeCustomCompletion();
    }
}