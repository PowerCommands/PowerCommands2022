﻿namespace PainKiller.PowerCommands.Shared.Utils.DisplayTable;

public enum Alignment
{
    Left,
    Right
}