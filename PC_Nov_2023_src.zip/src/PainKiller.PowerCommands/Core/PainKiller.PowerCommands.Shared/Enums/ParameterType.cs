﻿namespace PainKiller.PowerCommands.Shared.Enums;

public enum ParameterType
{
    Argument,
    Quote,
    Option,
    Secret
}