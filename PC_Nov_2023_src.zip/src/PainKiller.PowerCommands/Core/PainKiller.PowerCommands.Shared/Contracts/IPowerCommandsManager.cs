﻿namespace PainKiller.PowerCommands.Shared.Contracts;
public interface IPowerCommandsManager
{
    void Run(string[] args);
}