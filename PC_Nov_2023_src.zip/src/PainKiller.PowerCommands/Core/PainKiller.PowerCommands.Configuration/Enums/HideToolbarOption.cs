﻿namespace PainKiller.PowerCommands.Configuration.Enums;

public enum HideToolbarOption
{
    Never,
    OnTextChange,
    OnCommandHighlighted
}