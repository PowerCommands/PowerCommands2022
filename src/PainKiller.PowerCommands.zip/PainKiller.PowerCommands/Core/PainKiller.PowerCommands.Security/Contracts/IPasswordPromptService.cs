﻿namespace PainKiller.PowerCommands.Security.Contracts;

public interface IPasswordPromptService
{
    string ReadPassword();
}