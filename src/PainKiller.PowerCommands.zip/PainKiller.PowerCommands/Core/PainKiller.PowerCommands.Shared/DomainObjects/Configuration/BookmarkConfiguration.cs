﻿namespace PainKiller.PowerCommands.Shared.DomainObjects.Configuration;

public class BookmarkConfiguration
{
    public List<BookmarkItemConfiguration> Bookmarks { get; set; } = new();
}