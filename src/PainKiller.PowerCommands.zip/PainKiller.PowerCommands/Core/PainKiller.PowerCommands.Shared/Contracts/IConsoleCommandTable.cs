﻿namespace PainKiller.PowerCommands.Shared.Contracts;
public interface IConsoleCommandTable { }