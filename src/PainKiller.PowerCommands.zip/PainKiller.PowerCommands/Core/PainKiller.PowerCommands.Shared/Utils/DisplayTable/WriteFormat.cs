﻿namespace PainKiller.PowerCommands.Shared.Utils.DisplayTable;

public enum WriteFormat
{
    Default = 0,
    MarkDown = 1,
    Alternative = 2,
    Minimal = 3
}