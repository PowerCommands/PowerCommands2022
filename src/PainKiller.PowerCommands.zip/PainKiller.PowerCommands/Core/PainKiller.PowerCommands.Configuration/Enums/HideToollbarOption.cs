﻿namespace PainKiller.PowerCommands.Configuration.Enums;

public enum HideToollbarOption
{
    Never,
    OnTextChange,
    OnCommandHighlighted
}